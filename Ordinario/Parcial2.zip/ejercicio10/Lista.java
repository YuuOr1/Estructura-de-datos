public class Lista
{
    private Nodo inicio;
    private Nodo fin;

    public Lista()
    {
        inicio = null;
        fin = null;
    }

    public Nodo getInicio() {
        return inicio;
    }

    public void setInicio(Nodo inicio) 
    {
        this.inicio = inicio;
    }

    public Nodo getFin() 
    {
        return fin;
    }

    public void setFin(Nodo fin) 
    {
        this.fin = fin;
    }

    public void Reuniciar()
    {
        inicio = fin = null;
    }

    public void Instertar(int Elem)
    {
        Nodo nuevo = new Nodo();
        nuevo.setElem(Elem);

        if(inicio == null && fin == null)
        {
            inicio = nuevo;
            fin = nuevo;
        }
        else
        {
            Nodo i = inicio;
            while(i.getnext() != null) 
            {
                i = i.getnext();
            }
            i.setnext(nuevo);
            nuevo.setBack(i);
            fin = nuevo;
        }
    }
        public void Borrar()
        {
            if(inicio == fin) //Vacio o con un elemento
                inicio = fin = null;

            else //mas de un elemento
            {
                Nodo aux = inicio.getnext();
                inicio.setnext(null);
                inicio = aux;
            }
        }

        public void BorraUltimo()
        {
            if(inicio == fin )
                inicio = fin = null;
            else
            {
                fin = fin.getBack();
                fin.getnext().setBack(null);
                fin.setnext(null);
            }
        }

        public void Mostrar()
        {
            Nodo i = inicio;
            while (i != null)
            {
                System.out.println(i.getElem());
                i = i.getnext();
            }
        }

        public void Buscar(int Elem)
        {
    
            boolean estado = false;
            Nodo i = inicio;
    
            while( i != null)
            {
                if(Elem == i.getElem())
                {
                    System.out.println("El elemento se encuentra en la lista.\n");
                    i = null;
                    estado = true; 
                }
                else
                {
                    i = i.getnext();
                }
            }
            if (estado == false)
                System.out.println("El elemento no se esncuentra en la lista\n");
            
        }

        


    }