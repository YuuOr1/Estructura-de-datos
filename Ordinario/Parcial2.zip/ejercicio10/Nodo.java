public class Nodo {
    private int Elem;
    private Nodo next; 
    private Nodo back; 

    public void setElem(int variable) 
    {
        Elem = variable;
    }
    
    public int getElem()
    {
        return Elem;
    }

    public void setnext(Nodo variable)
    {
        next = variable;
    }
    public Nodo getnext()
    { 
        return next;
    }

    public Nodo getBack() {
        return back;
    }

    public void setBack(Nodo variable) {
        this.back = variable;
    }
}
