public class Nodo
{
    private String Elem;
    private Nodo next; 

    public void setElem(String variable) 
    {
        Elem = variable;
    }
    
    public String getElem()
    {
        return Elem;
    }

    public void setNext(Nodo variable)
    {
        next = variable;
    }
    public Nodo getNext()
    { 
        return next;
    }
}
