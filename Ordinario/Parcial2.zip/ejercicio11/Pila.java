public class Pila{
    private Nodo Cabeza=null;
    private Nodo fin=null;

    public Pila()
    {
        Cabeza = null;
        fin = null;
    }

    public Nodo getCabeza() { return Cabeza; }
    public void setCabeza(Nodo cabeza) { Cabeza = cabeza; }

    public Nodo getFin() { return fin; }
    public void setFin(Nodo fin) { this.fin = fin; }

    public void insertar(String Elem)
    {
        Nodo Nuevo = new Nodo(); 
        Nuevo.setElem(Elem);
        if(Cabeza==null && Cabeza==fin)
        {
            Cabeza=Nuevo;
            fin=Nuevo;
        }
        else
        {
            Cabeza.setNext(Nuevo);
            Cabeza = Nuevo;
        }
    }

    public void mostrar()
    {
        Pila Aux = new Pila();
        while(Cabeza != null)
        {
            System.out.println(Cabeza.getElem());
            Aux.insertar(Cabeza.getElem());
            this.borrar();
        }

        //

    }

    public void borrar()
    {
        if(Cabeza == fin)
            Cabeza = fin = null;
        else
        {
            Nodo i = fin;
            while(i.getNext() != Cabeza)
                i = i.getNext();
            i.setNext(null);
            Cabeza = i;
        }
    }

    public void limpiar()
    {
        Cabeza=fin=null;
    }
}