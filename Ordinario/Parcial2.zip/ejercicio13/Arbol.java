public class Arbol 
{
    private Nodo Raiz;

    public Nodo getRaiz() { return Raiz; }
    public void setRaiz(Nodo raiz) { Raiz = raiz; }

    public Arbol()
    {
        Raiz = null;
    }

    public boolean vacio()
    {
        return (Raiz == null);
    }

    public void Insertar(int Elem)
    {
        Nodo nuevo = new Nodo();
        nuevo.setElem(Elem);

        if(vacio())
            Raiz = nuevo;
        else
        {
            Nodo i = Raiz;
            while(i!=null)
            {
                if(Elem > i.getElem())
                {
                    if(i.getDer() == null)
                    {
                        i.setDer(nuevo);
                        i = null;
                    }
                        else
                        i = i.getDer();
                } 
                else
                {
               
                    if(i.getIzq() == null) 
                    {
                        i.setIzq(nuevo);
                        i = null;
                    }
                    else 
                        i = i.getIzq();
                } 
            }
        }
    }

    public void MostrarPreOrden(Nodo aux)
    {
        if(aux != null)
        {
            System.out.print(aux.getElem() + " - ");
            MostrarPreOrden(aux.getIzq());
            MostrarPreOrden(aux.getDer());
        }
    }

    public void MostrarInOrden(Nodo aux)
    {
        if(aux != null)
        {
            MostrarInOrden(aux.getIzq());
            System.out.print(aux.getElem() + " - ");
            MostrarInOrden(aux.getDer());
        }
    }

    public void MostrarPostOrden(Nodo aux)
    {
        if(aux != null)
        {
            MostrarPostOrden(aux.getIzq());
            MostrarPostOrden(aux.getDer());
            System.out.print(aux.getElem() + " - ");
        }
    }

    public void Mayor_Menor(Nodo aux)
    {
        if(aux != null)
        {
            Mayor_Menor(aux.getDer());
            System.out.print(aux.getElem() + " - ");
            Mayor_Menor(aux.getIzq());
        }
    }

    public boolean Buscar(int num)
    {
        Nodo i = Raiz;
        boolean encontrado = false;
        while(i != null && !encontrado)
        {
            if(i.getElem() == num) // si el numero es igual al nodo
                encontrado = true;
            else
                i = (num > i.getElem()) ? i.getDer() : i.getIzq(); // si no es igual, se mueve a la derecha o izquierda
        }
        return encontrado;
    }

    
}
