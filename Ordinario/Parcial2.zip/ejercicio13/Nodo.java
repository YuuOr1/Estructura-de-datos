public class Nodo{
   private int Elem;
   private Nodo der;
   private Nodo izq;


   public int getElem() { return Elem; }
   public void setElem(int elem) {Elem = elem;}

   public Nodo getDer() {return der;}
   public void setDer(Nodo der) {this.der = der;}

   public Nodo getIzq() {return izq;}
   public void setIzq(Nodo izq) {this.izq = izq;}

   

}