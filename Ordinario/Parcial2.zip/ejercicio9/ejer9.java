import java.io.FileInputStream;
import java.io.InputStream;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class ejer9{
    public static void main(String[] args) throws Exception
{
        System.out.println("-------------------- Ejercicio 9 --------------------\n");

        Scanner leer = new  Scanner(System.in);
        Colas Fila1 = new Colas();
        Colas Fila2 = new Colas();
        Colas Unifila = new Colas();
        String nombre;

        //carga datos automaticamente
        CargarDatos("Fila1.txt", Fila1);
        CargarDatos("Fila2.txt", Fila2);
        
        int opc = 0;

        do{
            menu();
            System.out.println("Elige: ");
            opc = Integer.parseInt(leer.nextLine());
            switch (opc)
            {
                case 1 -> 
                {
                    System.out.print("Nombre para agragar: ");
                    nombre = leer.nextLine();
                    Fila1.Instertar(nombre, 0, null);
                    System.out.println("\n");
                }

                case 2 -> 
                {
                    System.out.println("Fila1:\n");
                    Fila1.Mostrar();
                    System.out.println("\n");
                    System.out.println("Fila2:\n");
                    Fila2.Mostrar();
                    System.out.println("\n");
                }

                case 3 -> 
                {
                    System.out.print("Nombre para buscar: ");
                    nombre = leer.nextLine();
                    System.out.println("\n");
                    Fila1.Buscar(nombre);
                }
                
                case 4 -> 
                {
                    Fila1.Borrar();
                    System.out.println("Primer elemento borrado! ");
                    System.out.println("\n");
                }

                case 5->
                {
                    Unifila.Combinar(Fila1, Fila2);
                    Unifila.Mostrar();
                    System.out.println();

                }

                case 9 -> System.out.println("Saliendo....\n");

            }
        }while(opc != 9);
    }

    public static void menu() 
    {

        System.out.println("                    Colas\n");
        System.out.println("1 -> Insertar"); 
        System.out.println("2 -> Mostrar separadas");
        System.out.println("3 -> Bucar");
        System.out.println("4 -> Borrar de fila 1");
        System.out.println("5 -> Unificar");
        System.out.println("9 -> Salir"); 

    }

    public static void CargarDatos(String archivo, Colas Fila) throws Exception
    {
        //carga de datos fila1
        InputStream ins  = new FileInputStream(archivo);
        Scanner obj = new Scanner(ins);

        String str = "";
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
        LocalDateTime dateTime;

        while (obj.hasNextLine())
        {
            String linea = obj.nextLine();
            String[] lines = linea.split(",");
            String parte1 = lines[0]; // nombre
            String parte2 = lines[1]; // hora
            str = "2024-09-24 " + parte2;
            dateTime = LocalDateTime.parse(str, formatter);
            
            Fila.Instertar(parte1,0, dateTime);
        }
        obj.close();
    }
}
