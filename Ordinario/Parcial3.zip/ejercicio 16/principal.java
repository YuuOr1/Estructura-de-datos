import java.util.PriorityQueue;

public class principal{
    public static void main(String[] args) 
    {
        PriorityQueue<tarea> colasPrioridad = new PriorityQueue<tarea>();

        // creacion de objetos
        colasPrioridad.add(new tarea(10, "Matematicas"));
        colasPrioridad.add(new tarea(3, "Redaccion"));
        colasPrioridad.add(new tarea(2, "Estadistica"));
        colasPrioridad.add(new tarea(4, "Estruccturas de datos"));

        System.out.println("------------------- Ejercicio 16 --------------------");

        //System.out.println("\nTareas extraidas en orden de prioridad:\n");
        //while (!colasPrioridad.isEmpty())
        //    System.out.println(colasPrioridad.poll());

        System.out.println();
        colasPrioridad.removeIf(filter -> filter.getPrioridad() == 2);
        colasPrioridad.removeIf(filter -> filter.getDescripcion().equals("Estruccturas de datos"));

        for (tarea tarea : colasPrioridad)
            System.out.println(tarea);
        System.out.println();

    }

}
