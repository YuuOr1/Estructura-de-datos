public class tarea  implements Comparable<tarea>{
    private int prioridad;
    private String descripcion;

    public tarea(int prioridad, String descripcion) {
        this.prioridad = prioridad;
        this.descripcion = descripcion;
    }

    @Override
    public int compareTo(tarea otra) {
        return Integer.compare(this.prioridad, otra.prioridad);
    }

    @Override
    public String toString() {
        return "Tarea{" + "prioridad=" + prioridad + ", descripcion=" + descripcion + '}';
    }

    public int getPrioridad() { return prioridad;}
    public void setPrioridad(int prioridad) { this.prioridad = prioridad;}

    public String getDescripcion() { return descripcion;}
    public void setDescripcion(String descripcion) { this.descripcion = descripcion;}

    
}
