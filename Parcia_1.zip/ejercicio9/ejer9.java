
import javax.naming.InitialContext;
import javax.print.attribute.standard.NumberOfInterveningJobs;


public class ejer9{

    insertar(String elem);



}