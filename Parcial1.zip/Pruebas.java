import java.util.Scanner;

public class Pruebas {
    public static void main(String[] args) {
        Scanner leer = new Scanner(System.in);
        int[] a = new int[10];
        int valor, continuar, pos = 0; // Inicializamos `pos` en 0
        System.out.println("Ejercicio 2 Jose Becerra");
        do {
            // Pedir datos
            System.out.println("Que valor quiere guardar?");
            valor = leer.nextInt();
            if (pos < 10) { // Verificamos que `pos` esté dentro de los límites
                a[pos] = valor;
                pos++; // Incrementamos `pos` después de guardar el valor
            } else {
                System.out.println("El arreglo está lleno.");
                break; // Salimos del bucle si el arreglo está lleno
            }
            System.out.println("Continuar 1/0");
            continuar = leer.nextInt();
        } while (continuar == 1 && pos < 10);
        
        for (int i = 0; i <= 9; i++) {
            System.out.println(i + " = " + a[i]);
        }
    }
}
