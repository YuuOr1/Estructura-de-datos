public class Lista
{
    private Nodo inicio;
    private Nodo fin;

    //valores iniciales
    public Lista()
    {
        inicio = null;
        fin = null;
    }
    public void setInicio(Nodo variable)
    {    
        inicio = variable;
    }

    public Nodo getInicio()
    {
        return inicio;
    }
    public void setFin(Nodo variable)
    {    
        fin = variable;
    }

    public Nodo getFin()
    {
        return fin;
    }

    public void direcciones()
    {
        System.out.println("inicio: " + inicio);
        System.out.println("fin: " + fin);
    }

    public void insertar(String Elem)
    {
        Nodo nuevo = new Nodo();
        nuevo.setElem(Elem);
    
        //lisat vacia coloca el primer elemento
        if (inicio == null)// lista vacia
        {
            inicio = nuevo;
            fin = nuevo;
        }
        else
        {
            Nodo i = inicio;
            while(i.getnext()!= null)
            {
                i = i.getnext();
            }
            i.setnext(nuevo);
            nuevo.setback(i);
            fin = nuevo;
        }
    }

    public void mostrar()
    {
        if(inicio != null)
        {
            Nodo i = inicio;
            while(i != null)
            {
                System.out.println(i.getElem());
                i = i.getnext();
            }
        }
    }

    public void InsertarInicio(String Elem)
    {
        Nodo nuevo = new Nodo();
        nuevo.setElem(Elem);
        Nodo aux = inicio;
        inicio = nuevo;
        nuevo.setnext(aux);
        aux.setback(inicio);
    }

    public void Buscar(String Elem)
    {

        boolean estado = false;
        Nodo i = inicio;

        while( i != null)
        {
            if(Elem.equals(i.getElem()))
            {
                System.out.println("El elemento se encuentra en la lista.\n");
                i = null;
                estado = true; 
            }
            else
            {
                i = i.getnext();
            }
        }
        if (estado == false)
            System.out.println("El elemento no se esncuentra en la lista\n");
        
    }

    public void InsertarEnMedio(String Elem, String colado)
    {
        
        boolean estado = false;
        Nodo nuevo =  new Nodo();
        nuevo.setElem(colado);
        Nodo i = inicio;
        Nodo ant = inicio;

        while(i != null && estado == false)
        {
            if(Elem.equals(i.getElem()))
            {
                estado = true; 

                if(i == inicio)
                {
                    InsertarInicio(colado);
                }
                else
                {
                    i.getback().setnext(nuevo);
                    nuevo.setnext(i);
                    nuevo.setback(i.getback());
                    i.setback(nuevo);
                }
                
            }
            else
            {
                i = i.getnext();
            }
        }

        if (estado == false)
            System.out.println("El elemento no se esncuentra en la lista\n");
    }
 
    public boolean Borrar(String Elem)
    {
        boolean estado = false;
        Nodo i = inicio;

        while( i != null && estado == false)
        {
            if(Elem.equals(i.getElem()))
            {
                estado = true;

                if(inicio == fin)
                { 
                    inicio = fin = null;
                }
                else if (i == inicio)
                {
                    inicio = inicio.getnext();
                    i.setnext(null);
                    inicio.setback(null);
                } 
                else
                {
                    if(i == fin)//Borra el ultimo
                    {
                        fin = fin.getback();
                        i.setback(null);
                        fin.setnext(null);
                    }
                    else// enmedio
                    {
                        i.getnext().setback(i.getback());
                        i.getback().setnext(i.getnext());
                        i.setnext(null);
                        i.setback(null);
                    }
                }
                
                estado = true; 
            }
            else i = i.getnext();

        }
        return estado;
    }

    public void limpiar()
    {
        inicio = fin = null;
    }

    public boolean vacio()
    {
        if(inicio == fin && inicio == null)
            return  true;
        else
            return false;
    }
}


