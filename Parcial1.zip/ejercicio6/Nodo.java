public class Nodo
{
    private String Elem;
    private Nodo next; //cuerda que unae a otro 
    private Nodo back;

    //get asignacion o conloca elemento en a caja
    //mas adelante se cambiaran el nombre de las variables
    public void setElem(String variable) 
    {
        Elem = variable;
    }
    
    //get permite visualizar el contenido, regresa 
    public String getElem()
    {
        return Elem;
    }

    public void setnext(Nodo variable)
    {
        next = variable;
    }
    public Nodo getnext()
    { 
        return next;
    }
    
    public void setback(Nodo variable)
    {
        back = variable;
    }
    public Nodo getback()
    { 
        return back;
    }
}
 