public class Nodo{
    private String Elem;
    private Nodo next; //cuerda que unae a otro 
    private Nodo back;

    public void setElem(String variable) 
    {
        Elem = variable;
    }
    
    //get permite visualizar el contenido, regresa 
    public String getElem()
    {
        return Elem;
    }

    public void setnext(Nodo variable)
    {
        next = variable;
    }
    public Nodo getnext()
    { 
        return next;
    }
    
    public void setback(Nodo variable)
    {
        back = variable;
    }
    public Nodo getback()
    { 
        return back;
    }
}